<?php ob_start();
session_start();
$end=time(); 
include("../login/start_timer.php"); 
include("../login/end_timer.php");
if ($_SESSION['validacao'] != "1")
{   
  header("Location:http://geoweb.embasanet.ba.gov.br/");
}
?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html;charset=ANSI" >
<title>GEO WEB</title>
<meta name="description" content="" />
<meta name="keywords" content="" />
<META HTTP-EQUIV="imagetoolbar" CONTENT="no">



<link href="skins/blue/styles.css" rel="stylesheet" type="text/css" id="theme-styles"/>
<link href="skins/blue/menubar.css" rel="stylesheet" type="text/css" id="theme-menu"/>

<link href="shared/styles.css" rel="stylesheet" type="text/css"/>
<link href="shared/control.css" rel="stylesheet" type="text/css"/>
<link href="shared/popup.css" rel="stylesheet" type="text/css"/>
<link href="shared/css/objects/ReferenceMap.css" rel="stylesheet" type="text/css"/>
<link href="shared/css/mapslider.css" rel="stylesheet" type="text/css"/>


<!--
	geomoose_onfiguration.js contains the application contents
-->
<script type="text/javascript" src="salvador_configuration.js"></script>
<script type="text/javascript" src="../gMaps/gMaps.js"></script>

<!-- This creates the VML/Canvas Bridge for IE -->
<!--[if IE]><script type="text/javascript" src="contrib/excanvas.js"></script><![endif]-->


<!-- This will load all of the GeoMOOSE Dependency Libraries -->
<script type="text/javascript" src="lib/GeoMOOSE.js"></script>
</head>



<body onload="main()" onresize="Events.triggerEvent('windowresize',null); ">
<div id="container">
	<iframe id="header_container"></iframe>
	<div id="middle_nav_container"><!-- Middle Navigation -->
		<div id="middle_nav">
		</div>
	</div>
	<div id="toolbar_container" class="Toolbar"><!-- Toolbar -->
		<!--<div id="toolbar" class="Toolbar"></div>-->

	</div>



		<div id="map" style="position: relative"><br/>
			<div id="mapObject" style="position: absolute; top: 0px; left: 0px; width: 100%; height: 100%; z-index: 2">
				&nbsp;
			</div>
		 </div>

		<div id="show_hide_panel"><!-- Maximize/Minimize Bar --><a id="show_hide_panel_control" href="javascript:toggleSidePanel()" title="Maximize/Minimize"></a></div>

		<div id="side_panel"><!-- Side Panel -->
			
			<center id="jumpToDiv" style="text-align: center; margin-bottom: 5px; visibility: hidden">
			</center>

			<div id="tabs" style="visibility: hidden">
			</div>

			<script type="text/javascript">
					</script>
			<div id="panel_header_container">
				<div id="panel_header_left"><img psrc="skins/%THEME%/images/panel_header_left.jpg" width="5" height="29" /></div>
				<div id="panel_header_center"></div>
				<div id="panel_header_right"><img psrc="skins/%THEME%/images/panel_header_right.jpg" width="5" height="29" /></div>
				<div id="clear"></div>
		  </div>
	
			<div id="panel_content_container">
				<style type="text/css">
					.hiddenPanel {
						overflow: hidden;
						height: 1px;
						top: -100%;
						position: absolute;
					}

					.visiblePanel {
						overflow: auto;
						height: auto;
						top: auto;
						position: static;
					}
				</style>
				<div id="content_map_layers" class="hiddenPanel"></div>
				<div id="content_visible_layers" class="hiddenPanel"></div>
				<div id="content_measure_tool" class="hiddenPanel">
					<table>
					<tr id="segment_row"><td id="segment_title">Segment Length:</td><td><span id="measure_segment_length">0</span></td></tr>
					<tr><td id="measure_title">Total Length:</td><td><span id="measure_tool_output">0</span></td></tr>
					<tr><td>&nbsp;</td><td>
					<select id="unitConversion" onchange="updateMeasureTool(this.oldValue)">
					</select>
					<input type="button" value="Clear" onclick="Map.resetDrawingArea(); clearMeasureTool();"/>
					</td>
					</tr>
					</table>
					<table>
						<tbody id="measure_tool_log">
						</tbody>
					</table>
				</div>
				<div id="content_service_form" class="hiddenPanel"></div>
				<div id="content_results_form" class="hiddenPanel"><b>No Services Selected</b>
				</div>
				<div id="content_tools_list" class="hiddenPanel">
					<div id="vertical_tool_list" class="Toolbar">
					</div>
				</div>
			</div>
		</div>

	<div id="clear"></div>

  	<div id="footer_container"><!-- Footer & Disclaimer -->
		<div id="disclaimer"><span id="disclaimer_organization"></span>&nbsp; <span id="CoordinateDisplay"></span></div>
	
		</div>
		<div id="scale_content"><b>Scale 1:</b></div>

	</div>

	<div id="reference_map">
	</div>
</div>
<!--
-->

<script type="text/javascript">


/* Layout stuff... */
if(true) {
	var refMap = document.getElementById('reference_map');
	refMap.style.visibility = 'visible';
	refMap.style.width = REFERENCE_MAP_WIDTH+'px';
	refMap.style.height =REFERENCE_MAP_HEIGHT+'px';
}



/*
 * Create new Objects and Relate them to their parents.
 */

var Events = new GEvents();

/* This needs to happen first! */
Events.addEventListener('windowresize', 'LayoutManager', onResize);


var Tools = new GTools(Events);
Tools.initializeEvents();

var ExtendedTools = null;
if(TOOLS_SHOW_TAB) {
	ExtendedTools = new GTools(Events);
	ExtendedTools.initializeEvents();
}

var Map = new GMap(Events);
Map.initializeEvents();

var ReferenceMapObj = false;
if(REFERENCE_MAP) {
	ReferenceMapObj = new ReferenceMap(Events);
	ReferenceMapObj.setMapRelation(Map);
	ReferenceMapObj.initializeEvents();
}

var Popups = new PopupManager(Events, Map);
Popups.initializeEvents();

var TreeView = new TreeView(Events, Map);
TreeView.initializeEvents();

var VisibleLayers = new VisibleLayers(Events,Map);
VisibleLayers.initializeEvents();

var ViewBox = new ViewBox(Events, Map);
ViewBox.initializeEvents();

var ServManager = new ServiceManager(Events, Map);
ServManager.initializeEvents();

var NavHistory = new NavigatorHistory(Events);
NavHistory.initializeEvents();

var Scalebox = new ScaleBox(Events,Map);
Scalebox.initializeEvents();

var LoadingBar = new GLoadingBar(Events,Map);
LoadingBar.initializeEvents();

ServManager.setResultsContainerId('content_results_form');

TreeView.setParent('content_map_layers');
VisibleLayers.setParent('content_visible_layers');

Map.setParent('mapObject');
if(ReferenceMapObj) {
	ReferenceMapObj.setParent('reference_map');
}

Scalebox.setParent('scale_content');
ServManager.setParent('content_service_form');
LoadingBar.setParent('map');


function clearMeasureTool() {
	var measuredAmount = document.getElementById('measure_tool_output');
	measuredAmount.innerHTML = '0';
	document.getElementById('measure_segment_length').innerHTML = '0';
	var mtLog = document.getElementById('measure_tool_log');
	while(mtLog.firstChild) {
		mtLog.removeChild(mtLog.firstChild);
	}

}

function updateCurrentLength(v) {
	if(v.length <= 2) {
		clearMeasureTool();
	}
	if(v.length >= 2) {
		var convert = document.getElementById('unitConversion');
		var opts = convert.getElementsByTagName('option');
		if(convert.selectedIndex >= 0) {
			var selOpt = opts[convert.selectedIndex];
			var unitCheck = new String(selOpt.value);
			if(unitCheck.substring(0,2) == 'SQ') {
				unitCheck = 'SQ';
			} else {
				unitCheck = '';
			}

			var gUnitSeg =new LineSegment(v[v.length-1],v[v.length-2]);
			var len = gUnitSeg.getLength();
			var unitValue = round(len*UNIT_CONVERSION[unitCheck+MAP_GROUND_UNITS][selOpt.value],2);
			document.getElementById('measure_segment_length').innerHTML = unitValue;
		}
	}
}

Events.addEventListener('measuring', 'measuretool', updateCurrentLength);

function updateMeasureTool(v) {
	var convert = document.getElementById('unitConversion');
	var opts = convert.getElementsByTagName('option');

	if(convert.selectedIndex >= 0) {
		var selOpt = opts[convert.selectedIndex];
		var unitCheck = new String(selOpt.value);
		var segOrArea = 'Segment';
		if(unitCheck.substring(0,2) == 'SQ') {
			unitCheck = 'SQ';

			segOrArea = 'Area';
		} else {
			unitCheck = '';
		}
		var unitValue = round(v*UNIT_CONVERSION[unitCheck+MAP_GROUND_UNITS][selOpt.value],2);

		var measuredAmount = document.getElementById('measure_tool_output');
		var oldAmount = parseFloat(measuredAmount.innerHTML.replace(/,/g, ''));

		if(unitValue - oldAmount > 0 && v > 0) {
			var measureToolLog = document.getElementById('measure_tool_log');
			rowC = measureToolLog.getElementsByTagName('tr').length;

			var logRow = document.createElement('tr');
			if(rowC == 0) {
				measureToolLog.appendChild(logRow);
			} else {
				measureToolLog.insertBefore(logRow, measureToolLog.firstChild);
			}

			var rowTitle = document.createElement('th');
			logRow.appendChild(rowTitle);
			rowTitle.appendChild(document.createTextNode(segOrArea+' '+(rowC + 1)));

			var logCell = document.createElement('td');
			logRow.appendChild(logCell);
			logCell.appendChild(document.createTextNode(commifyNumber(round(unitValue - oldAmount,2))));

			measuredAmount.innerHTML = commifyNumber(unitValue);
		}

	}
}

function updateMeasureIndicator() {
	var convert = this;
	var len = document.getElementById(this.targetId);
	var oldUnits = convert.oldUnits;
	var v = len.value;
	var opts = convert.getElementsByTagName('option');
	if(convert.selectedIndex >= 0) {
		var selOpt = opts[convert.selectedIndex];
		var unitCheck = new String(selOpt.value);
		v = Math.round(v*UNIT_CONVERSION[oldUnits][selOpt.value]);
		convert.oldUnits = selOpt.value;
	}
	len.value = v;

}

/*
 * Measure Tool Functionality
 */

Events.addEventListener('measure', 'MeatureTool', clearMeasureTool);
/*Events.addEventListener('finishdrawing', 'MeasureTool', clearMeasureTool);*/

Events.addEventListener('measuredlength', 'MeasureTool', function (v) {
	var convert = document.getElementById('unitConversion');
	convert.oldValue = v;
	updateMeasureTool(v);
});

/*
 * Events Captured by the Extended Toolbar
 */
if(ExtendedTools) {
	if(TOOLS_DIVIDE_PANEL) {
		Events.removeEventListener('addservice', 'Tools');

		Events.addEventListener('addservice', 'Tools', function(servXML) {
			if(servXML.getAttribute('locked') && servXML.getAttribute('locked').match(/true/i)) {
				Tools.addService(servXML);
			}
		});
	}
}



/*
 * Initial Loading Events
 */


Events.addEventListener('loadedmapbook', 'treeview', TreeView.loadMapbook);
Events.addEventListener('loadedmapbook', 'defaults', loadDefaults); /* From Defaults.js */
Events.addEventListener('loadedmapbook', 'ServManager', ServManager.onloadMapbook);
Events.addEventListener('loadedmapbook', 'disclaimer', showDisclaimer); /* From Defaults.js */

Events.addEventListener('loadedmapbook', 'Defaults',
	function (xmlDoc) {
		Events.removeEventListener('loadedmapbook', 'Defaults');
		mapbookLoadedEvents(xmlDoc);
	});


Tools.setParent('toolbar_container');

if(TOOLS_SHOW_TAB) {
	ExtendedTools.SHOW_TEXT = 'true';
	ExtendedTools.setType('ToolListVertical');
	ExtendedTools.setParent('vertical_tool_list');
}


if(MAP_COORDINATE_DISPLAY.groundUnits || MAP_COORDINATE_DISPLAY.lonLat) {
	Map.setCoordinateObject('CoordinateDisplay');
}

function onResize() {
	var footer = document.getElementById('footer_container');
	var map = document.getElementById('map');
	var sidePanelControl = document.getElementById('show_hide_panel');
	var sidePanel = document.getElementById('side_panel');
	var referenceMap = document.getElementById('reference_map');

	map.style.overflow = 'hidden';
	var hBorder = 6;
	map.style.width = footer.offsetWidth - (sidePanelControl.offsetWidth + sidePanel.offsetWidth) - hBorder + 'px';
	map.style.minWidth = map.style.width;

	if(!SIDE_PANEL_RIGHT) {
		sidePanel.style.left = '0px';
		sidePanel.style.right = 'auto';
		sidePanelControl.style.left = sidePanel.offsetWidth + 'px';
		sidePanelControl.style.right = 'auto';
		map.style.left = sidePanel.offsetWidth + sidePanel.offsetLeft + hBorder * 2 + 'px';

	} else {
		sidePanelControl.style.left = 'auto';
		sidePanelControl.style.right = sidePanel.offsetWidth + 'px';
	}

	var toolbar = document.getElementById('toolbar_container');
	var sidePanelControlLink  = document.getElementById('show_hide_panel_control');
	var vBorder = 6;
	var Height = footer.offsetTop - (toolbar.offsetHeight + toolbar.offsetTop);
	map.style.height = (Height-vBorder)+'px';
	sidePanelControl.style.height = (Height)+'px';
	sidePanel.style.height = (Height-vBorder)+'px';
	sidePanelControlLink.style.height = (Height)+'px';

	var panelContent= document.getElementById('panel_content_container');
	var panelHeader = document.getElementById('panel_header_container');
	panelContent.style.height = Height - (panelHeader.offsetTop + panelHeader.offsetHeight) - vBorder * 2+ 'px';
//	panelContent.style.height = Height - panelContent.offsetTop - 6 + 'px';

	/*
	 * Position the reference map.
	 */

	var mapRight = map.offsetLeft + map.offsetWidth;
	var referenceMapW = referenceMap.offsetWidth + 5;
	if(REFERENCE_MAP_LEFT) {
		referenceMap.style.left = '4px';
	} else {
		referenceMap.style.left = mapRight - referenceMapW + 'px';
	}
	referenceMap.style.right = 'auto';
	if(REFERENCE_MAP_TOP) {
		referenceMap.style.top = map.offsetTop + 5 + 'px';
	} else {
		referenceMap.style.top = map.offsetTop + map.offsetHeight - referenceMap.offsetHeight - 5 + 'px';
	}
	referenceMap.style.bottom = 'auto';


}
function toggleSidePanel() {
	var sidePanelControl = document.getElementById('show_hide_panel');
	var sidePanel = document.getElementById('side_panel');
	sidePanel.style.overflow = 'hidden';
	if(sidePanel.style.visibility == 'hidden') {
		sidePanel.style.visibility = 'visible';
		sidePanel.style.width = sidePanel.oldWidth;
	} else {
		sidePanel.style.visibility = 'hidden';
		sidePanel.oldWidth = sidePanel.style.width;
		sidePanel.style.width = '1px';
	}
	Events.triggerEvent('windowresize',null);
}

var Tabs = new TabManager('panel_header_center', 'hiddenPanel', 'visiblePanel', Events);
Tabs.addTab('MEASURE LENGTH', 'content_measure_tool');
Tabs.addTab('MEASURE AREA', 'content_measure_tool');

Events.addEventListener('changetab', 'TabManager', Tabs.showTab);
Events.addEventListener('lasttab', 'TabManager', Tabs.showLastTab);

/*
 * This is to handle the  tab changing if document tabs are enabled.
 */
function handleSelectedTab(tName) {
	var allLinks = document.getElementById('tabs').getElementsByTagName('a');
	for(var i = 0; i < allLinks.length; i++) {
		allLinks[i].className = '';
	}
	var selected = document.getElementById('tab-'+tName);
	if(selected) {
		selected.className = 'selected';
	}
}
Events.addEventListener('changetab','DocumentTabs',handleSelectedTab);


function finishedWithService(serviceXMLObj) {
	var title = new String(serviceXMLObj.getAttribute('title')).toUpperCase();
	Events.removeEventListener('changetool', 'ServiceContent');
	document.getElementById('content_service_form').innerHTML = '';
	Map.setMapCursor(CURSOR_NOTHING);
}

function cancelService(xml) {
	finishedWithService(xml);
	Tabs.showLastTab();
}



function changePointScale(x,y,s) {
	var modCirc = new Circle();
	modCirc.Center = new Point(x,y);
	modCirc.Radius = s;
	modCirc.Markup = true;
	Events.triggerEvent('navigate', modCirc);
}

Events.addEventListener('cancelservice', 'ServiceContent', cancelService);
var currentTitle = '';
Events.addEventListener('serviceform', 'ServiceContent', function (serviceXMLObj) {
	currentTitle = Tabs.getCurrentTab();
	var title = new String(serviceXMLObj.getAttribute('title')).toUpperCase();
	Tabs.addTab(title, 'content_service_form');
	Events.triggerEvent('changetab',title);

	ServManager.serviceForm(serviceXMLObj);
	Events.addEventListener('changetool', 'ServiceContent', function () {
		finishedWithService(serviceXMLObj);
		Events.removeEventListener('changetool','ServiceContent');
	});
	if(new String(serviceXMLObj.getAttribute('display')).match(/none/i)) {
		Events.addEventListener('callservice', 'ServiceContentNoneDisplay', function () {
			Tabs.showLastTab();
		});
	}

});


function showMeasureTab(mType) {
	var measureTitle = document.getElementById('measure_title');
	var v = new String(mType);
	var unitType = v.substring(0,1).toUpperCase() + v.substring(1);
	measureTitle.innerHTML = 'Total '+ unitType  + ':';

	document.getElementById('segment_title').innerHTML = 'Segment ' + unitType + ':';

	var incrementalRow = document.getElementById('segment_row');
	if(mType == 'area') {
		incrementalRow.style.display = 'none';
	} else {
		incrementalRow.style.display = '';
	}

	populateUnitConversionSelection(mType, document.getElementById('unitConversion'));

	Events.addEventListener('changetool', 'MeasureToolPanel', function () {
		Events.removeEventListener('changetool', 'MeasureToolPanel');
		Tabs.showLastTab();
	});

	Events.triggerEvent('changetab', 'MEASURE '+new String(mType).toUpperCase());
	measureTitle = null;
}
Events.addEventListener('measure', 'MeasureTool', showMeasureTab);

    var pi = 3.14159265358979;

    /* Ellipsoide (WGS84) */
    /* var sm_a = 6378137.0; */
    var sm_a = 6378160.0; 
    var sm_b = 6356752.314;
    var sm_EccSquared = 6.69437999013e-03;
    var wnumero = 0
    var wgrau = 0
    var wmin = 0
    var wsec = 0
    var UTMScaleFactor = 0.9996;



    function DegToRad (deg)
    {
        return (deg / 180.0 * pi)
    }





    function RadToDeg (rad)
    {
        return (rad / pi * 180.0)
    }


/*

    function ArcLengthOfMeridian (phi)
    {
        var alpha, beta, gamma, delta, epsilon, n;
        var result;

        
        n = (sm_a - sm_b) / (sm_a + sm_b);

        
        alpha = ((sm_a + sm_b) / 2.0)
           * (1.0 + (Math.pow (n, 2.0) / 4.0) + (Math.pow (n, 4.0) / 64.0));

        beta = (-3.0 * n / 2.0) + (9.0 * Math.pow (n, 3.0) / 16.0)
           + (-3.0 * Math.pow (n, 5.0) / 32.0);


        gamma = (15.0 * Math.pow (n, 2.0) / 16.0)
            + (-15.0 * Math.pow (n, 4.0) / 32.0);
    
        delta = (-35.0 * Math.pow (n, 3.0) / 48.0)
            + (105.0 * Math.pow (n, 5.0) / 256.0);
    

        epsilon = (315.0 * Math.pow (n, 4.0) / 512.0);
    

    result = alpha
        * (phi + (beta * Math.sin (2.0 * phi))
            + (gamma * Math.sin (4.0 * phi))
            + (delta * Math.sin (6.0 * phi))
            + (epsilon * Math.sin (8.0 * phi)));

    return result;
    }
*/



    function UTMCentralMeridian (zone)
    {
        var cmeridian;

        cmeridian = DegToRad (-183.0 + (zone * 6.0));
    
        return cmeridian;
    }




    function FootpointLatitude (y)
    {
        var y_, alpha_, beta_, gamma_, delta_, epsilon_, n;
        var result;
        
        
        n = (sm_a - sm_b) / (sm_a + sm_b);
        	
        alpha_ = ((sm_a + sm_b) / 2.0)
            * (1 + (Math.pow (n, 2.0) / 4) + (Math.pow (n, 4.0) / 64));
        
        
        y_ = y / alpha_;
        
        
        beta_ = (3.0 * n / 2.0) + (-27.0 * Math.pow (n, 3.0) / 32.0)
            + (269.0 * Math.pow (n, 5.0) / 512.0);
        
        
        gamma_ = (21.0 * Math.pow (n, 2.0) / 16.0)
            + (-55.0 * Math.pow (n, 4.0) / 32.0);
        	
        
        delta_ = (151.0 * Math.pow (n, 3.0) / 96.0)
            + (-417.0 * Math.pow (n, 5.0) / 128.0);
        	
        
        epsilon_ = (1097.0 * Math.pow (n, 4.0) / 512.0);
        	
       
        result = y_ + (beta_ * Math.sin (2.0 * y_))
            + (gamma_ * Math.sin (4.0 * y_))
            + (delta_ * Math.sin (6.0 * y_))
            + (epsilon_ * Math.sin (8.0 * y_));
        
        return result;
    }


/*

    function MapLatLonToXY (phi, lambda, lambda0, xy)

    {
        var N, nu2, ep2, t, t2, l;
        var l3coef, l4coef, l5coef, l6coef, l7coef, l8coef;
        var tmp;

        
        ep2 = (Math.pow (sm_a, 2.0) - Math.pow (sm_b, 2.0)) / Math.pow (sm_b, 2.0);
    
        
        nu2 = ep2 * Math.pow (Math.cos (phi), 2.0);
    
        
        N = Math.pow (sm_a, 2.0) / (sm_b * Math.sqrt (1 + nu2));
    
        
        t = Math.tan (phi);
        t2 = t * t;
        tmp = (t2 * t2 * t2) - Math.pow (t, 6.0);

        
        l = lambda - lambda0;
    

        l3coef = 1.0 - t2 + nu2;
    
        l4coef = 5.0 - t2 + 9 * nu2 + 4.0 * (nu2 * nu2);
    
        l5coef = 5.0 - 18.0 * t2 + (t2 * t2) + 14.0 * nu2
            - 58.0 * t2 * nu2;
    
        l6coef = 61.0 - 58.0 * t2 + (t2 * t2) + 270.0 * nu2
            - 330.0 * t2 * nu2;
    
        l7coef = 61.0 - 479.0 * t2 + 179.0 * (t2 * t2) - (t2 * t2 * t2);
    
        l8coef = 1385.0 - 3111.0 * t2 + 543.0 * (t2 * t2) - (t2 * t2 * t2);
    
        
        xy[0] = N * Math.cos (phi) * l
            + (N / 6.0 * Math.pow (Math.cos (phi), 3.0) * l3coef * Math.pow (l, 3.0))
            + (N / 120.0 * Math.pow (Math.cos (phi), 5.0) * l5coef * Math.pow (l, 5.0))
            + (N / 5040.0 * Math.pow (Math.cos (phi), 7.0) * l7coef * Math.pow (l, 7.0));
    
        
        xy[1] = ArcLengthOfMeridian (phi)
            + (t / 2.0 * N * Math.pow (Math.cos (phi), 2.0) * Math.pow (l, 2.0))
            + (t / 24.0 * N * Math.pow (Math.cos (phi), 4.0) * l4coef * Math.pow (l, 4.0))
            + (t / 720.0 * N * Math.pow (Math.cos (phi), 6.0) * l6coef * Math.pow (l, 6.0))
            + (t / 40320.0 * N * Math.pow (Math.cos (phi), 8.0) * l8coef * Math.pow (l, 8.0));
    
        return;
    }
    
    */
    

    function MapXYToLatLon (x, y, lambda0, philambda)
    {
        var phif, Nf, Nfpow, nuf2, ep2, tf, tf2, tf4, cf;
        var x1frac, x2frac, x3frac, x4frac, x5frac, x6frac, x7frac, x8frac;
        var x2poly, x3poly, x4poly, x5poly, x6poly, x7poly, x8poly;
    	
        
        phif = FootpointLatitude (y);
        	
        
        ep2 = (Math.pow (sm_a, 2.0) - Math.pow (sm_b, 2.0))
              / Math.pow (sm_b, 2.0);
        	
        
        cf = Math.cos (phif);
        	
        
        nuf2 = ep2 * Math.pow (cf, 2.0);
        	
        
        Nf = Math.pow (sm_a, 2.0) / (sm_b * Math.sqrt (1 + nuf2));
        Nfpow = Nf;
        	
        
        tf = Math.tan (phif);
        tf2 = tf * tf;
        tf4 = tf2 * tf2;
        

        x1frac = 1.0 / (Nfpow * cf);
        
        Nfpow *= Nf;   /* now equals Nf**2) */
        x2frac = tf / (2.0 * Nfpow);
        
        Nfpow *= Nf;   /* now equals Nf**3) */
        x3frac = 1.0 / (6.0 * Nfpow * cf);
        
        Nfpow *= Nf;   /* now equals Nf**4) */
        x4frac = tf / (24.0 * Nfpow);
        
        Nfpow *= Nf;   /* now equals Nf**5) */
        x5frac = 1.0 / (120.0 * Nfpow * cf);
        
        Nfpow *= Nf;   /* now equals Nf**6) */
        x6frac = tf / (720.0 * Nfpow);
        
        Nfpow *= Nf;   /* now equals Nf**7) */
        x7frac = 1.0 / (5040.0 * Nfpow * cf);
        
        Nfpow *= Nf;   /* now equals Nf**8) */
        x8frac = tf / (40320.0 * Nfpow);
        

        x2poly = -1.0 - nuf2;
        
        x3poly = -1.0 - 2 * tf2 - nuf2;
        
        x4poly = 5.0 + 3.0 * tf2 + 6.0 * nuf2 - 6.0 * tf2 * nuf2
        	- 3.0 * (nuf2 *nuf2) - 9.0 * tf2 * (nuf2 * nuf2);
        
        x5poly = 5.0 + 28.0 * tf2 + 24.0 * tf4 + 6.0 * nuf2 + 8.0 * tf2 * nuf2;
        
        x6poly = -61.0 - 90.0 * tf2 - 45.0 * tf4 - 107.0 * nuf2
        	+ 162.0 * tf2 * nuf2;
        
        x7poly = -61.0 - 662.0 * tf2 - 1320.0 * tf4 - 720.0 * (tf4 * tf2);
        
        x8poly = 1385.0 + 3633.0 * tf2 + 4095.0 * tf4 + 1575 * (tf4 * tf2);
        	

        philambda[0] = phif + x2frac * x2poly * (x * x)
        	+ x4frac * x4poly * Math.pow (x, 4.0)
        	+ x6frac * x6poly * Math.pow (x, 6.0)
        	+ x8frac * x8poly * Math.pow (x, 8.0);
        	

        philambda[1] = lambda0 + x1frac * x
        	+ x3frac * x3poly * Math.pow (x, 3.0)
        	+ x5frac * x5poly * Math.pow (x, 5.0)
        	+ x7frac * x7poly * Math.pow (x, 7.0);
        	
        return;
    }





//    function LatLonToUTMXY (lat, lon, zone, xy)
 //   {
//        MapLatLonToXY (lat, lon, UTMCentralMeridian (zone), xy);

        /* Adjust easting and northing for UTM system. */
  //      xy[0] = xy[0] * UTMScaleFactor + 500000.0;
    //    xy[1] = xy[1] * UTMScaleFactor;
  //      if (xy[1] < 0.0)
//            xy[1] = xy[1] + 10000000.0;

  //      return zone;
    //}
    
    
    

    function UTMXYToLatLon (x, y, zone, southhemi, latlon)
    {
        var cmeridian;
        	
        x -= 500000.0;
        x /= UTMScaleFactor;
        	
        /* If in southern hemisphere, adjust y accordingly. */
        if (southhemi)
        y -= 10000000.0;
        		
        y /= UTMScaleFactor;
        
        cmeridian = UTMCentralMeridian (zone);
          MapXYToLatLon (x, y, cmeridian, latlon);
        	
        return;
    }
    


/**

    function btnToUTM_OnClick ()
    {
        var xy = new Array(2);
        if (document.frmConverter.txtlongraus.value!=null) {
           wgrau = parseFloat (document.frmConverter.txtlongraus.value); 
           wmin = parseFloat (document.frmConverter.txtlonmin.value) / 60;
           wsec = parseFloat (document.frmConverter.txtlonsec.value) / 3600;
           wnumero = wgrau + wmin + wsec 
           wnumero = wnumero * -1
           document.frmConverter.txtLongitude.value = wnumero;
        }   
        if (isNaN (parseFloat (document.frmConverter.txtLongitude.value))) {
            alert ("Entre com uma longitude valida.");
            return false;
        }

        lon = parseFloat (document.frmConverter.txtLongitude.value);

        if ((lon < -180.0) || (180.0 <= lon)) {
            alert ("Entre com um numero para latitude entre -180, 180.");
            return false;
        }
        
        if (document.frmConverter.txtlatgraus.value!=null) {
           wgrau = parseFloat (document.frmConverter.txtlatgraus.value); 
           wmin = parseFloat (document.frmConverter.txtlatmin.value) / 60;
           wsec = parseFloat (document.frmConverter.txtlatsec.value) / 3600;
           wnumero = wgrau + wmin + wsec 
           wnumero = wnumero * -1;
           document.frmConverter.txtLatitude.value = wnumero;
        }   

        if (isNaN (parseFloat (document.frmConverter.txtLatitude.value))) {
            alert ("Entre com uma latitude valida.");
            return false;
        }

        lat = parseFloat (document.frmConverter.txtLatitude.value);

        if ((lat < -90.0) || (90.0 < lat)) {
            alert ("Entre com um numero para latitude entre -90, 90.");
            return false;
        }


        zone = Math.floor ((lon + 180.0) / 6) + 1;

        zone = LatLonToUTMXY (DegToRad (lat), DegToRad (lon), zone, xy);


        document.frmConverter.txtX.value = xy[0];
        document.frmConverter.txtY.value = xy[1];
        document.frmConverter.txtZone.value = zone;
        if (lat < 0)
            // Set the S button.
            document.frmConverter.rbtnHemisphere[1].checked = true;
        else
            // Set the N button.
            document.frmConverter.rbtnHemisphere[0].checked = true;
 //       var Win1 = open("http://www.rdtec.com.br/rdgeomg/visucxy/rdgeomg.asp?IDX="  + RadToDeg (latlon[0]) + "&IDY=" + RadToDeg (latlon[1]),"QueryWindow","width=550,height=350,scrollbars=no,resizable=no");
        return true;
    }



    function btnToGeographic_OnClick ()
    {                                  
        latlon = new Array(2);
        var x, y, zone, southhemi;
        
        if (isNaN (parseFloat (document.frmConverter.txtX.value))) {
            alert ("Entre com uma Coordenada valida para X.");
            return false;
        }

        x = parseFloat (document.frmConverter.txtX.value);
        x = x - 75;
        if (isNaN (parseFloat (document.frmConverter.txtY.value))) {
            alert ("Entre com uma Coordenada valida para Y.");
            return false;
        }

        y = parseFloat (document.frmConverter.txtY.value);
        y = y - 25;

        if (isNaN (parseInt (document.frmConverter.txtZone.value))) {
            alert ("Entre com uma Zona valida.");
            return false;
        }

        zone = parseFloat (document.frmConverter.txtZone.value);

        if ((zone < 1) || (60 < zone)) {
            alert ("Zona Inv?lida entre com um n?mero de 1 ? 60");
            return false;
        }
        
        if (document.frmConverter.rbtnHemisphere[1].checked == true)
            southhemi = true;
        else
            southhemi = false;

        UTMXYToLatLon (x, y, zone, southhemi, latlon);
        
        document.frmConverter.txtLongitude.value = RadToDeg (latlon[1]);
        document.frmConverter.txtLatitude.value = RadToDeg (latlon[0]);
        wnumero = Math.abs(RadToDeg (latlon[1]));
        wgrau = Math.floor(wnumero);
        wmin = Math.floor((wnumero - wgrau) * 60);
        wsec = Math.floor((((wnumero - wgrau) * 60) - wmin) * 60);
        document.frmConverter.txtlongraus.value = wgrau;
        document.frmConverter.txtlonmin.value = wmin;
        document.frmConverter.txtlonsec.value = wsec;
        wnumero = Math.abs(RadToDeg (latlon[0]));
        wgrau = Math.floor(wnumero);
        wmin = Math.floor((wnumero - wgrau) * 60);
        wsec = Math.floor((((wnumero - wgrau) * 60) - wmin) * 60);
        document.frmConverter.txtlatgraus.value = wgrau;
        document.frmConverter.txtlatmin.value = wmin;
        document.frmConverter.txtlatsec.value = wsec;
//        var Win1 = open("http://www.rdtec.com.br/rdgeomg/visucxy/rdgeomg.asp?IDX="  + RadToDeg (latlon[0]) + "&IDY=" + RadToDeg (latlon[1]),"QueryWindow","width=525,height=325,scrollbars=no,resizable=no");
        return true;
    }
    function EnderClick ()
    {
     //alert (document.frmender.T1.value);
//     var Win1 = open("http://www.rdtec.com.br/rdgeomg/visuende/rdgeomg.asp?IDENDER="  + document.frmender.T1.value,"QueryWindow","width=525,height=325,scrollbars=no,resizable=no");
    } 
     
    //    -->
**/
/*
function goStreetView(x, y, zona) {

	latlon = new Array(2);
	
	var latitude, longitude;
	
	x = x - 75;
	y = y - 25;
	

	UTMXYToLatLon (x, y, zona, true, latlon);

	latitude = RadToDeg (latlon[0]);
	longitude = RadToDeg (latlon[1]);
	url = "https://maps.google.com/maps?q=" + latitude + "," + longitude + "&layer=c&z=17&iwloc=A&sll=" + latitude + "," + longitude + "&cbp=13,45.4,0,0,0&cbll=" + latitude + "," + longitude + "&ved=0CAsQ2wU&sa=X&ei=SqPdUfX1OITXtgeL2IGgCA";
	
	window.open(url);
	//https://maps.google.com/maps?q=-12.946897,-38.374854&layer=c&z=17&iwloc=A&sll=-12.946840,-38.374940&cbp=13,45.4,0,0,0&cbll=-12.946958,-38.375063&ved=0CAsQ2wU&sa=X&ei=SqPdUfX1OITXtgeL2IGgCA
	
}

// 2017/02/01
// Função retorma mapa do GoogleMaps
function goGMaps(x, y, zona, gmType){

	latlon = new Array(2);
	
	var latitude, longitude;
	
	x = x - 75;
	y = y - 25;
	

	UTMXYToLatLon (x, y, zona, true, latlon);

	latitude = RadToDeg (latlon[0]);
	longitude = RadToDeg (latlon[1]);
	url = "http://geoweb.embasanet.ba.gov.br/gMaps/gMap.html";
	
//	window.open("http://geoweb.embasanet.ba.gov.br/gMaps/gMap.html?la="+latitude+"&lo="+longitude+"&tp="+gmType);
	if(gmType == 'ROADMAP'){
		window.open("http://maps.google.com/maps?z=12&t=m&q=loc:"+latitude+"+"+longitude);
	}else if(gmType == 'SATELLITE'){

		window.open("http://maps.google.com/maps?z=12&t=h&q=loc:"+latitude+"+"+longitude);
	}else if(gmType == 'TERRAIN'){
		window.open("http://maps.google.com/maps?z=12&t=k&q=loc:"+latitude+"+"+longitude);
	}else{
		window.open("http://maps.google.com/maps?z=12&t=k&q=loc:"+latitude+"+"+longitude);
	}		
}
*/

	function helpwin(){
                window.open("http://www.uol.com.br","Help","toolbar=0, scrollbars=1, menubar=0, location=0, resizable=1, status=0, left=100, top=100, width=975, height=700");
	}



</script>

<div id="CustomForms">

	<div id="BuscarConsumidor">
		<font color="black"><b>Buscar Consumidor:</b></font><br/>
		<!--
		<input type="hidden" name="map" value=""/>
		<input type="hidden" name="mode" value="itemnquery">
		<input type="hidden" name="qlayer" value="umb" [umb_check]>
		-->
		<select name="qitem">
			<option value="matricula">Matricula</option>
			<option value="NOME_CONS">Nome Do Consumidor</option>
			<option value="CPF_CNPJ">CPF/CNPJ</option>
			<option value="ENDERECO">Endereco</option>
			<option value="TELEFONE">Telefone</option>
			<option value="NUM_HIDR">Numero do Hidrometro</option>
			<option value="QUADRA">Quadra (quadra-zona)</option>			
		</select>
		<input type="text" name="qstring" value="">
		<input type="submit" value="Buscar"/>
	</div>	

	<div id="BuscarRua">	
		<font color="black"><b>Buscar Logradouro:</b></font><br/>
		<!--
		<input type="hidden" name="map" value=""/>
		<input type="hidden" name="mode" value="itemnquery">
		<input type="hidden" name="qlayer" value="eixo" [eixo_check]>
		-->
		<select name="qitem">
			<option value="codigo">CODIGO</option>
			<option value="RUA">RUA</option>			
		</select>
		<input type="text" name="qstring" value="">
		<input type="submit" value="Buscar"/>
	</div>

	<div id="BuscarDmc">
		<font color="black"><b>Buscar DMC:</b></font><br/>
		<!--
		<input type="hidden" name="map" value=""/>
		<input type="hidden" name="mode" value="itemnquery">
		<input type="hidden" name="qlayer" value="umb" [umb_check]>
		-->
		<select name="qitem">
			<option value="numero_dmc">DMC (numero_dmc-zona)</option>
			<!--<option value="Zona">Zona</option>
			<option value="CPF_CNPJ">CPF/CNPJ</option>
			<option value="ENDERECO">Endere\E7o</option>
			<option value="TELEFONE">Telefone</option>
			<option value="NUM_HIDR">Numero do Hidr\F4metro</option>
			<option value="QUADRA">Quadra (quadra-zona)</option>-->			
		</select>
		<input type="text" name="qstring" value="">
		<input type="submit" value="Buscar"/>
	</div>	
  <div id="sair">
                <font color="black"><b>Confirmar a saida?</b></font><br/>



 <input type="button" value="sim" onclick="javascript:window.open('','_parent','');window.close();"/>
 <input type="reset" value="nao" onclick="javaScript:window.refresh();"/>


<!--
                <input type="hidden" name="map" value=""/>
                <input type="hidden" name="mode" value="itemnquery">
                <input type="hidden" name="qlayer" value="eixo" [eixo_check]>
              -->
</div>


 <div id="gerargrafico">
              
FUNCIONALIDDADE AINDA EM CONSTRUCAO
 <input type="button" value="Consumidores por vazao" onclick="javascript:window.open('http://geoweb.embasanet.ba.gov.br/salvador_view/php/graficosporvazaoumf/graficosumf.php','page','toolbar=no,location=no,status=no,menubar=no,scrollbars=no,resizable=no,width=200,height=200');"/>


<!--
                <input type="hidden" name="map" value=""/>
                <input type="hidden" name="mode" value="itemnquery">
                <input type="hidden" name="qlayer" value="eixo" [eixo_check]>
              -->
</div>

	<br>


	

</div>


	<div id="WaitingMessage">
		<font color="red"><b>Pesquisando, Favor Aguarde...</b></font><br/>
	</div>


</body>
</html>
